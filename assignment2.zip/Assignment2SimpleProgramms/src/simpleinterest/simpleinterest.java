package simpleinterest;

import java.util.*;

public class simpleinterest {
	public static float InterestCalculator(int no, float rate, int duration) {
		float result = (no * rate * duration) / 100;
		return result;
	}

	public static void main(String args[]) {
		Scanner sobj = new Scanner(System.in);
		System.out.println("Enter the amount");
		int no = sobj.nextInt();
		if (no <= 0) {
			System.exit(0);
		}
		System.out.println("Enter the rate");
		float rate = sobj.nextFloat();
		if (rate <= 0) {
			System.exit(0);
		}
		System.out.println("Enter the duration in year");
		int duration = sobj.nextInt();
		if (duration <= 0) {
			System.exit(0);
		}
		Float result = InterestCalculator(no, rate, duration);
		System.out.println(result);
	}
}
