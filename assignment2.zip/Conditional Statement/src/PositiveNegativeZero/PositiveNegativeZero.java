package PositiveNegativeZero;

import java.util.Scanner;

public class PositiveNegativeZero {
     public static void PositiveNegativeAndZero(int no)
	{
		if(no==0)
		{
			System.out.println("zero");
		}
		else if(no > 0)
		{
			System.out.println("Positive");
		}
		else
		{
			System.out.println("Negative");
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sobj= new Scanner(System.in);
		try
		{
		System.out.println("Enter the number");
		int no=sobj.nextInt();
		PositiveNegativeAndZero(no);
		}
		catch(Exception e)
		{
			System.out.println("Invalid input");
		}
}
}