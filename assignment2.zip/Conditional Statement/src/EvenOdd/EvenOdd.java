package EvenOdd;

import java.util.*;

public class EvenOdd {
	public static boolean evenodd(int no) {
		if (no % 2 == 0) {
			return true;
		}
		return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sobj = new Scanner(System.in);
		System.out.println("Enter the number");
		int no = sobj.nextInt();

		if (evenodd(no)) {
			System.out.println("even number");
		} else {
			System.out.println("odd number");
		}
	}

}
