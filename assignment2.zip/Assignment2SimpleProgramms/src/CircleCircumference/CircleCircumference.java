package CircleCircumference;

import java.util.*;

public class CircleCircumference {
	static final double P_I = 3.1416;

	public static double Area(double radius) {
		// pi cannot be changed
		return P_I * radius * radius;

	}

	public static double Circumference(double radius) {
		return 2 * P_I * radius;
	}

	public static void main(String[] args) {
		double radius;
		Scanner sobj = new Scanner(System.in);
		System.out.println("enter the radius");
		radius = sobj.nextDouble();

		System.out.println("Area of circle is " + Area(radius));
		System.out.println("Circumference of a circle is " + Circumference(radius));
	}

}
