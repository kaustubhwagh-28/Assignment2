package GreatestNumber;
import java.util.*;
public class GreatestNumber {
	public static int greatestnumber(int no1,int no2,int no3)
	{
		if((no1 > no2) && (no1> no3))
		{
			return no1;
		}
		else if((no2 > no1) && (no2> no3))
		{
			return no2;
		}
		else
		{
			return no3;
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	   Scanner sobj =new Scanner(System.in);
       System.out.println("Enter the three numbers");
       int no1=sobj.nextInt();
       int no2=sobj.nextInt();
       int no3=sobj.nextInt();
       int no=greatestnumber(no1,no2,no3);
       System.out.println("Greatest of three numbers is "+no);
       
	}

}
