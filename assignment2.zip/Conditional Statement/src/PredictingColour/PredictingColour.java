package PredictingColour;

import java.util.*;

public class PredictingColour {

	public static void main(String[] args) {
		int value=07;
		
		Scanner sobj = new Scanner(System.in);
		System.out.println("enter the value");
		value = sobj.nextInt();
		if ((value == -10) || (value == -3) || (value == 7) || (value == 12) || (value == 22)) {
			System.out.println("RED");
		} else if ((value == 11) || (value == 15) || (value == 19) || (value == 25) || (value == 32)) {
			System.out.println("YELLOW");
		} else if ((value >= 50 && value <= 53) || (value >= 60 && value <= 63)) {
			System.out.println("BLUE");
		} else if ((value == 60) || (value == 100) || (value == 200) || (value == 210)) {
			System.out.println("GREEN");
		} else {
			System.out.println("BLACK");
		}
	}

}
