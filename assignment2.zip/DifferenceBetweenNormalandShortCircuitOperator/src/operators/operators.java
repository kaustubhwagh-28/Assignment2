package operators;

public class operators {
public static boolean first()
{
	System.out.println("In programme first");
	return true;
}
public static  boolean second()
{
	System.out.println("In programme second");
	return true;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
if(first() || second())
{
	System.out.println("It will call only first method seeing result as true it will not call the next method");
	
}
if(first() | second())
{
	System.out.println("It will call both method");
	
}
	}

}
