package Grades;
import java.util.*;
public class Grades {
	public static char gradedecider(float avg)
		{
		if(avg <= 49)
		{
			return 'F';
		}
		else if((avg > 49) && (avg <= 65))
		{
			return 'D';
		}
		else if((avg > 65) && (avg <=75))
		{
			return 'C';
		}
		else if((avg > 75) && (avg <=85))
		{
			return 'C';
		}
		else {
			return 'A';
		}
		
		
	 }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sobj = new Scanner(System.in);
 int arr[]=new int[3];
 System.out.println("enter the internal marks out of 100");
 for(int i=0;i<3;i++)
 {
	arr[i] = sobj.nextInt(); 
 }
 Arrays.sort(arr);
 int num=arr[1]+arr[2];
 System.out.println("enter the external marks out of 100");
 int no=sobj.nextInt();
float avg=(num + no)/3;       //getting the avg
char c=gradedecider(avg);
System.out.println("grade is "+c);
	}

}
