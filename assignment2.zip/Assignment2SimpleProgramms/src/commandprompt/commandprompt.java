package commandprompt;

public class commandprompt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int first = Integer.parseInt(args[0]);
		int second = Integer.parseInt(args[1]);
		int result = first + second;
		System.out.println(result);

	}

}
