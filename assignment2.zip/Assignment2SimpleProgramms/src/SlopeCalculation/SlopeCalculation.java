package SlopeCalculation;

import java.util.*;

public class SlopeCalculation {
	public static double slope(float x1, float y1, float x2, float y2) {
		double result = 0;
		try {
			result = (y2 - y1) / (x2 - x1);
		} catch (ArithmeticException e) {
			System.out.println("0");
		}
		if (result == -0) {
			result = 0;
		}
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sobj = new Scanner(System.in);
		System.out.println("Enter the x1");
		float x1 = sobj.nextFloat();

		System.out.println("Enter the y1");
		float y1 = sobj.nextFloat();

		System.out.println("Enter the x2");
		float x2 = sobj.nextFloat();

		System.out.println("Enter the y2");
		float y2 = sobj.nextFloat();

		System.out.println(slope(x1, y1, x2, y2));
	}

}
