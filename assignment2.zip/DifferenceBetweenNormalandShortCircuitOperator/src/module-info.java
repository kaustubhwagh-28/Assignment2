module DifferenceBetweenNormalandShortCircuitOperator {
}